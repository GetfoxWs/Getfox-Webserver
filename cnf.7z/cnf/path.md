   Private Sub SitedataGridView_CellMouseLeave(sender As Object, e As DataGridViewCellEventArgs) Handles SitedataGridView.CellMouseLeave
        Cursor = Cursors.Default

        For i As Integer = 0 To SitedataGridView.Rows.Count - 1
            SitedataGridView.Rows(i).Cells("OpenUrl").Value = My.Resources.DG_L
            SitedataGridView.Rows(i).Cells("OpenFolder").Value = My.Resources.DG_F
            SitedataGridView.Rows(i).Cells("OpenDb").Value = My.Resources.DG_D
        Next
    End Sub

    Private Sub SitedataGridView_CellMouseMove(sender As Object, e As DataGridViewCellMouseEventArgs) Handles SitedataGridView.CellMouseMove

        Cursor = Cursors.Default
        ' sender.Rows(e.RowIndex).Cells(CellsName).Value = Image
        Try
            If TypeOf sender.Columns(e.ColumnIndex) Is DataGridViewImageColumn Then
                Dim CellsName = sender.Columns(e.ColumnIndex).Name
                Dim Image As Image
                Select Case CellsName 'isPhp
                    Case "OpenUrl"
                        Image = My.Resources.DG_L
                    Case "OpenFolder"
                        Image = My.Resources.DG_F
                    Case "OpenDb"
                        Image = My.Resources.DG_D
                End Select
                Cursor = Cursors.Hand
                sender.Rows(e.RowIndex).Cells(CellsName).Value = scaleMX(Image, RGBColors.color8)
            Else
                Cursor = Cursors.Default
                '  sender.Rows(e.RowIndex).Cells(CellsName).Value = Image
            End If
        Catch ex As Exception

        End Try

    End Sub